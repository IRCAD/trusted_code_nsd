double median(double *a, double *w, const int N);

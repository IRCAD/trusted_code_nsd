# Data
Please download the datasets required for demos:
[GBCPD/GBCPD++ dataset](https://www.dropbox.com/s/yssce2kmdil3fqs/gbcpd-demodata20220829.zip?dl=1).
[BCPD dataset](https://www.dropbox.com/s/6kd4uiyt150uyz9/bcpd-demodata20200127.zip?dl=1),
[BCPD++ dataset](https://www.dropbox.com/s/um46xujczko39jk/bcpd-pp-demodata20210226.zip?dl=1),
If you have trouble downloading them, go to [bcpd-dataset](https://github.com/ohirose/bcpd-dataset).

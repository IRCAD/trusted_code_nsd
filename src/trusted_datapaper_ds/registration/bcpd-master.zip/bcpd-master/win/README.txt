This is the binary files of the BCPD for windows, compiled by gcc on mingw32.
When you run bcpd.exe, move point set files into this directory; do not move
bcpd.exe and related library files from this directory.

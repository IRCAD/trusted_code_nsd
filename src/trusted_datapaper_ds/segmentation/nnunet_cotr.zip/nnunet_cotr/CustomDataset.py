from torch.utils.data import Dataset
# from monai.data import Dataset
import monai
from monai.transforms import apply_transform, LoadImage
import random
from CustomTransform import CustomRandCropByPosNegLabeld
from monai.transforms import RandCropByPosNegLabeld, Compose
# from tools import log_debug, log_info, log_start, log_end
import numpy as np

from tools import downsample_seg_for_ds_transform3
import data as dt

import torch

class CustomDataset(Dataset):
	def __init__(self, data, transform=None, iterations=250, log=None, net_num_pool_op_kernel_sizes=[], type_='train', 
		multi_anno=True, num_classes=2, name="us",*args, **kwargs):
		super().__init__(*args, **kwargs)
		# We use our own Custom dataset wich with we can keep track of sub volumes position.
		self.data = monai.data.Dataset(data)
		self.iterations = iterations
		self.loader = LoadImage()
		self.n_data = len(data)
		self.transform = transform
		self.log=log
		self.type=type_
		self.multi_anno = multi_anno
		self.num_classes = num_classes
		self.name=name
		self.net_num_pool_op_kernel_sizes = net_num_pool_op_kernel_sizes
		self.idx = -1

	def __len__(self):
		if self.type == 'train':
			if self.iterations == 0:
				return len(self.data)
			return self.iterations
		else:
			return len(self.data)

	def __getitem__(self, index):
		log=self.log
		# log.debug("index", index)
		# log.debug("n_data", self.n_data)
		if self.type == 'train':
			if self.iterations == 0:
				self.idx += 1
				i = self.idx
			else:
				i = random.randint(0,self.n_data-1)
		else:
			self.idx += 1
			i = self.idx

		data_i = {}
		# log.debug("pth", self.data[i])

		img = dt.Image(self.data[i]["image"])
		mask = dt.Mask(self.data[i]["label"], annotatorID='gt')
		data_i["image"] = np.expand_dims(img.nparray, axis=0)
		data_i["label"] = np.expand_dims(mask.nparray, axis=0)
  
		# data_i["image"] = rearrange(np.load(self.data[i]["image"])['arr_0'][None, ...], 'b x y z -> b z x y')
		# data_i["label"] = rearrange(np.load(self.data[i]["label"])['arr_0'][None, ...], 'b x y z -> b z x y')
		if self.multi_anno:
			# data_i["label1"] = rearrange(np.load(self.data[i]["label1"])['arr_0'][None, ...], 'b x y z -> b z x y')
			# data_i["label2"] = rearrange(np.load(self.data[i]["label2"])['arr_0'][None, ...], 'b x y z -> b z x y')
			mask1 = dt.Mask(self.data[i]["label1"], annotatorID='1')
			mask2 = dt.Mask(self.data[i]["label2"], annotatorID='1')
			data_i["label"] = np.expand_dims(mask1.nparray, axis=0)
			data_i["label"] = np.expand_dims(mask2.nparray, axis=0)

		data_i["id"] = [self.data[i]["image"].split('/')[-1].replace('_img', '_xxx')]
		data_i["affine"] = img.nibaffine
		data_i["size"] = img.size

		# centers = [[0,0,0]]
		# if not (self.type == 'test'):
		# 	# data_i, centers = self.croper(data_i)
		# 	# data_i = data_i[0]
		# 	# TODO : customise RandCropByLabelClassesd to return centers
		# 	centers = [centers[0][2]-shape[3]//2,centers[0][0]-shape[1]//2,centers[0][1]-shape[2]//2]


		if self.transform != None:
			# Apply transformations
			tmp = apply_transform(self.transform, data_i)
			if type(tmp) == type([]):
				data_i = tmp[0] if self.transform is not None else data_i
			else:
				data_i = tmp if self.transform is not None else data_i

			# data_i["image"] = torch.from_numpy(data_i["image"].numpy())
			data_i["image"] = torch.from_numpy(data_i["image"])


		# data_i["center"] = np.array(centers)

		
		# Do deep supervision on labels
		if self.net_num_pool_op_kernel_sizes!=[]:
			deep_supervision_scales = [[1, 1, 1]] + list(list(i) for i in 1 / np.cumprod(
	            np.vstack(self.net_num_pool_op_kernel_sizes), axis=0))[:-1]

			# self.log.debug("label shape", data_i["label"][None,...].numpy().shape)
			# data_i["label"] = downsample_seg_for_ds_transform3(data_i["label"][None,...].numpy(), deep_supervision_scales, classes=[i for i in range(self.num_classes)], log=self.log)
			data_i["label"] = downsample_seg_for_ds_transform3(data_i["label"][None,...], deep_supervision_scales, classes=[i for i in range(self.num_classes)], log=self.log)
			# self.log.debug("label[0] shape", data_i["label"][0][None,...].numpy().shape)

			# exit(0)
			

			if self.multi_anno:
				data_i["label1"] = downsample_seg_for_ds_transform3(data_i["label1"][None,...].numpy(), deep_supervision_scales, classes=[i for i in range(self.num_classes)])
				data_i["label2"] = downsample_seg_for_ds_transform3(data_i["label2"][None,...].numpy(), deep_supervision_scales, classes=[i for i in range(self.num_classes)])



		return data_i

